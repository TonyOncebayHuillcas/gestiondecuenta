import React, { Component } from 'react';
import Tabs from './components/tabs';
import styles from './css/nstyle.css';

class App extends Component {

  render() {
    return (
      <div>
        <Tabs />
      </div>
    )
  }
  
}

//Exporta tabs
export default App;
