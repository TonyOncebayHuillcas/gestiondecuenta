import React, {Component} from 'react';

class MovimientoInterno extends Component {
    render() {
        return (
            <div className="row justify-content-center mt-3">
                <div className="col-6 align-self-center">
                    <h2 className="text-center">Aún estamos desarrollando esta funcionalidad</h2>
                </div>
            </div>
        );
    }
}

export default MovimientoInterno;