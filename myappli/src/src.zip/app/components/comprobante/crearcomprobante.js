import React, {Component} from 'react';

class CrearComprobante extends Component {
    render() {
        return (
            <div>
                Hola
            </div>
        );
    }
}

export default CrearComprobante;